from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

# The key used for decryption, converted to bytes
key = b"UREnzskykID5MWlMYoBpT67E6wuF19QJ"

def decrypt_file(file_path, key):
    with open(file_path, "rb") as encrypted_file:
        # Assuming the nonce size is 12 bytes (standard for AES-GCM)
        nonce, ciphertext = encrypted_file.read(12), encrypted_file.read()
        
        # Initialize AES GCM with the given key
        aesgcm = AESGCM(key)
        
        # Decrypt the content
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        
        # Write the decrypted content back to the file
        with open(file_path, "wb") as decrypted_file:
            decrypted_file.write(plaintext)

# Example usage for a single file
# decrypt_file("path/to/encrypted/file", key)

# Decrypt all files in specified directories
TGT_DIRS = ["Documents", "Downloads", "Music", "Pictures", "Videos", "Desktop", "./"]

def decrypt_dir(dir_path, key):
    os.chdir(os.path.expanduser('~'))
    for root, dirs, files in os.walk(dir_path):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                decrypt_file(file_path, key)
                print(f"Decrypted: {file_path}")
            except Exception as e:
                print(f"Failed to decrypt {file_path}: {e}")

# Loop through the target directories and decrypt each file
for dir in TGT_DIRS:
    decrypt_dir(dir, key)
